import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { generateRequestSchema, inputSchemas } from "@/lib/validators";
import { chargeAndCreateDocument, refundDocument, InsufficientPointsError } from "@/lib/points";
import { generateContent } from "@/lib/ai/ai-service";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) {
    return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  }
  const userId = session.user.id;

  const body = generateRequestSchema.safeParse(await req.json().catch(() => null));
  if (!body.success) {
    return NextResponse.json({ error: "INVALID_REQUEST", details: body.error.flatten() }, { status: 400 });
  }
  const { serviceId, language, inputData } = body.data;

  const service = await prisma.service.findUnique({ where: { id: serviceId } });
  if (!service || !service.isActive) {
    return NextResponse.json({ error: "SERVICE_UNAVAILABLE" }, { status: 404 });
  }

  const input = inputSchemas[service.templateType].safeParse(inputData);
  if (!input.success) {
    return NextResponse.json({ error: "INVALID_INPUT", details: input.error.flatten() }, { status: 400 });
  }

  let document;
  try {
    document = await chargeAndCreateDocument({
      userId,
      serviceId: service.id,
      cost: service.pointsCost,
      inputData: input.data,
      language,
    });
  } catch (e) {
    if (e instanceof InsufficientPointsError) {
      return NextResponse.json({ error: "INSUFFICIENT_POINTS_OR_BANNED" }, { status: 402 });
    }
    throw e;
  }

  try {
    const content = await generateContent(service.templateType, language, input.data);

    await prisma.document.update({
      where: { id: document.id },
      data: { outputContent: content, status: "COMPLETED" },
    });

    const { pointsBalance } = await prisma.user.findUniqueOrThrow({
      where: { id: userId },
      select: { pointsBalance: true },
    });

    return NextResponse.json({ documentId: document.id, content, pointsBalance });
  } catch (err) {
    console.error("[generate] AI failure", err);
    await refundDocument(document.id, err instanceof Error ? err.message : "AI error");
    return NextResponse.json({ error: "AI_FAILED_REFUNDED" }, { status: 502 });
  }
}
