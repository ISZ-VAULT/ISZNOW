import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getAdminSession } from "@/lib/session";
import { generateCardCode } from "@/lib/cards";

const schema = z.object({
  packName: z.string().min(1).max(60).default("Pack Pro"),
  points: z.number().int().min(1).max(1_000_000),
  priceDzd: z.number().int().min(0).max(10_000_000),
  quantity: z.number().int().min(1).max(500).default(10),
});

export async function POST(req: Request) {
  const admin = await getAdminSession();
  if (!admin) return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "INVALID_REQUEST", details: parsed.error.flatten() }, { status: 400 });
  }
  const { packName, points, priceDzd, quantity } = parsed.data;

  // Unique codes (in-memory set, then check against the DB)
  const codes = new Set<string>();
  while (codes.size < quantity) codes.add(generateCardCode());
  const existing = await prisma.rechargeCard.findMany({
    where: { code: { in: [...codes] } },
    select: { code: true },
  });
  for (const e of existing) codes.delete(e.code);
  while (codes.size < quantity) {
    const c = generateCardCode();
    if (!(await prisma.rechargeCard.findUnique({ where: { code: c } }))) codes.add(c);
  }

  const batch = await prisma.rechargeBatch.create({
    data: {
      packName,
      points,
      priceDzd,
      quantity,
      createdById: admin.id,
      cards: {
        create: [...codes].map((code) => ({ code, points, priceDzd })),
      },
    },
  });

  return NextResponse.json({ batchId: batch.id, packName, points, priceDzd, codes: [...codes] });
}
