import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getAdminSession } from "@/lib/session";

const schema = z.union([
  z.object({ action: z.literal("toggleBan") }),
  z.object({ action: z.literal("setPoints"), points: z.number().int().min(0).max(10_000_000) }),
]);

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const admin = await getAdminSession();
  if (!admin) return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "INVALID_REQUEST" }, { status: 400 });

  const target = await prisma.user.findUnique({ where: { id: params.id } });
  if (!target) return NextResponse.json({ error: "NOT_FOUND" }, { status: 404 });
  if (target.role === "ADMIN") {
    return NextResponse.json({ error: "CANNOT_MODIFY_ADMIN" }, { status: 400 });
  }

  if (parsed.data.action === "toggleBan") {
    const user = await prisma.user.update({
      where: { id: target.id },
      data: { isBanned: !target.isBanned },
      select: { id: true, isBanned: true },
    });
    return NextResponse.json(user);
  }

  const newBalance = parsed.data.points;
  const delta = newBalance - target.pointsBalance;
  const user = await prisma.$transaction(async (tx) => {
    const u = await tx.user.update({
      where: { id: target.id },
      data: { pointsBalance: newBalance },
      select: { id: true, pointsBalance: true },
    });
    if (delta !== 0) {
      await tx.transaction.create({
        data: {
          userId: target.id,
          type: "ADJUSTMENT",
          method: "ADMIN",
          points: delta,
          balanceAfter: newBalance,
        },
      });
    }
    return u;
  });
  return NextResponse.json(user);
}
