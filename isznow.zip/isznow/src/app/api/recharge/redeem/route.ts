import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const schema = z.object({
  code: z.string().transform((v) => v.replace(/\D/g, "")).pipe(z.string().length(12)),
});

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) {
    return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  }
  const userId = session.user.id;

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "INVALID_CODE_FORMAT" }, { status: 400 });
  }
  const code = parsed.data.code;

  try {
    const result = await prisma.$transaction(async (tx) => {
      const card = await tx.rechargeCard.findUnique({ where: { code } });
      if (!card) return { error: "CARD_NOT_FOUND" as const };
      if (card.isUsed) return { error: "CARD_ALREADY_USED" as const };

      // Atomic claim: only one request can flip isUsed from false to true.
      const claimed = await tx.rechargeCard.updateMany({
        where: { id: card.id, isUsed: false },
        data: { isUsed: true, usedByUserId: userId, usedAt: new Date() },
      });
      if (claimed.count === 0) return { error: "CARD_ALREADY_USED" as const };

      const user = await tx.user.update({
        where: { id: userId },
        data: { pointsBalance: { increment: card.points } },
        select: { pointsBalance: true },
      });

      await tx.transaction.create({
        data: {
          userId,
          type: "RECHARGE",
          method: "CARD_CODE",
          points: card.points,
          amountDzd: card.priceDzd,
          balanceAfter: user.pointsBalance,
          rechargeCardId: card.id,
        },
      });

      return { pointsAdded: card.points, pointsBalance: user.pointsBalance };
    });

    if ("error" in result) {
      const status = result.error === "CARD_NOT_FOUND" ? 404 : 409;
      return NextResponse.json({ error: result.error }, { status });
    }
    return NextResponse.json(result);
  } catch (err) {
    console.error("[redeem]", err);
    return NextResponse.json({ error: "SERVER_ERROR" }, { status: 500 });
  }
}
