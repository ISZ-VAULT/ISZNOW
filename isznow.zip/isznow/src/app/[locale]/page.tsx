import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export default async function Home({ params }: { params: { locale: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) redirect(`/${params.locale}/login`);
  redirect(session.user.role === "ADMIN" ? `/${params.locale}/admin` : `/${params.locale}/dashboard`);
}
