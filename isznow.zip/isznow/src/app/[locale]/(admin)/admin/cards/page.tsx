import { prisma } from "@/lib/prisma";
import { formatCode, formatDate } from "@/lib/utils";
import { Badge, Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CardsGenerator } from "@/components/admin/cards-generator";

export const metadata = { title: "بطاقات الشحن" };

export default async function AdminCardsPage({ params }: { params: { locale: string } }) {
  const [cards, unused, used] = await Promise.all([
    prisma.rechargeCard.findMany({
      orderBy: { createdAt: "desc" },
      take: 50,
      include: { batch: { select: { packName: true } }, usedBy: { select: { name: true } } },
    }),
    prisma.rechargeCard.count({ where: { isUsed: false } }),
    prisma.rechargeCard.count({ where: { isUsed: true } }),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">بطاقات الشحن</h1>
        <p className="text-sm text-muted-foreground">
          غير مستعملة: <b>{unused}</b> · مستعملة: <b>{used}</b>
        </p>
      </div>

      <CardsGenerator />

      <Card>
        <CardHeader>
          <CardTitle>آخر 50 بطاقة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-muted-foreground">
                  <th className="px-3 py-2 text-start font-medium">الكود</th>
                  <th className="px-3 py-2 text-start font-medium">الباقة</th>
                  <th className="px-3 py-2 text-start font-medium">النقاط</th>
                  <th className="px-3 py-2 text-start font-medium">الحالة</th>
                  <th className="px-3 py-2 text-start font-medium">استعملها</th>
                  <th className="px-3 py-2 text-start font-medium">التاريخ</th>
                </tr>
              </thead>
              <tbody>
                {cards.map((c) => (
                  <tr key={c.id} className="border-b last:border-0">
                    <td className="px-3 py-3 font-mono font-bold" dir="ltr">{formatCode(c.code)}</td>
                    <td className="px-3 py-3">{c.batch.packName}</td>
                    <td className="px-3 py-3">{c.points}</td>
                    <td className="px-3 py-3">
                      <Badge tone={c.isUsed ? "danger" : "success"}>{c.isUsed ? "مستعملة" : "متاحة"}</Badge>
                    </td>
                    <td className="px-3 py-3 text-muted-foreground">{c.usedBy?.name ?? "—"}</td>
                    <td className="px-3 py-3 text-muted-foreground">{formatDate(c.createdAt, params.locale)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
