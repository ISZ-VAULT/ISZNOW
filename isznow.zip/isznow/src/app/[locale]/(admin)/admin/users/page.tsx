import { prisma } from "@/lib/prisma";
import { Card, CardContent } from "@/components/ui/card";
import { UsersTable } from "@/components/admin/users-table";

export const metadata = { title: "الوكلاء" };

export default async function AdminUsersPage() {
  const users = await prisma.user.findMany({
    where: { role: "AGENT" },
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { documents: true } } },
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">الوكلاء</h1>
        <p className="text-sm text-muted-foreground">إدارة الحسابات والرصيد. اضغط على الرصيد لتعديله.</p>
      </div>
      <Card>
        <CardContent className="p-5">
          <UsersTable
            users={users.map((u) => ({
              id: u.id,
              name: u.name,
              email: u.email,
              pointsBalance: u.pointsBalance,
              isBanned: u.isBanned,
              createdAt: u.createdAt.toISOString(),
              docs: u._count.documents,
            }))}
          />
        </CardContent>
      </Card>
    </div>
  );
}
