import { requireAdminPage } from "@/lib/session";
import { AppShell, type NavItem } from "@/components/layout/app-shell";

export const dynamic = "force-dynamic";

export default async function AdminLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  const user = await requireAdminPage(params.locale);
  const base = `/${params.locale}/admin`;

  const nav: NavItem[] = [
    { href: base, label: "الإحصائيات", icon: "dashboard" },
    { href: `${base}/users`, label: "الوكلاء", icon: "users" },
    { href: `${base}/cards`, label: "بطاقات الشحن", icon: "cards" },
  ];

  return (
    <AppShell locale={params.locale} nav={nav} exactHref={base} userName={user.name} roleLabel="مدير النظام">
      {children}
    </AppShell>
  );
}
