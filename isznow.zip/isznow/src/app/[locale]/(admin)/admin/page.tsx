import { Banknote, Coins, FileText, Users } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { formatDate, formatNumber } from "@/lib/utils";
import { Badge, Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const metadata = { title: "لوحة المدير" };

export default async function AdminHome({ params }: { params: { locale: string } }) {
  const [users, docs, revenue, pointsUsed, recent] = await Promise.all([
    prisma.user.count({ where: { role: "AGENT" } }),
    prisma.document.count({ where: { status: "COMPLETED" } }),
    // Revenue = retail price of every card that has been redeemed
    prisma.rechargeCard.aggregate({ where: { isUsed: true }, _sum: { priceDzd: true } }),
    prisma.document.aggregate({ where: { status: "COMPLETED" }, _sum: { pointsCharged: true } }),
    prisma.document.findMany({
      orderBy: { createdAt: "desc" },
      take: 8,
      include: { user: { select: { name: true } }, service: { select: { nameAr: true } } },
    }),
  ]);

  const stats = [
    { label: "إجمالي الإيرادات", value: `${formatNumber(revenue._sum.priceDzd ?? 0)} دج`, icon: Banknote, color: "bg-emerald-100 text-emerald-600" },
    { label: "عدد الوكلاء", value: formatNumber(users), icon: Users, color: "bg-indigo-100 text-indigo-600" },
    { label: "الوثائق المولّدة", value: formatNumber(docs), icon: FileText, color: "bg-sky-100 text-sky-600" },
    { label: "النقاط المستهلكة", value: formatNumber(pointsUsed._sum.pointsCharged ?? 0), icon: Coins, color: "bg-amber-100 text-amber-600" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">لوحة المدير</h1>
        <p className="text-sm text-muted-foreground">إحصائيات منصة ISZ Now</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardContent className="flex items-center gap-4 p-5">
              <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${s.color}`}>
                <s.icon className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{s.label}</p>
                <p className="text-xl font-extrabold">{s.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>آخر الوثائق من كل الوكلاء</CardTitle>
        </CardHeader>
        <CardContent>
          {recent.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">لا توجد وثائق بعد</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-muted-foreground">
                    <th className="px-3 py-2 text-start font-medium">الوكيل</th>
                    <th className="px-3 py-2 text-start font-medium">الخدمة</th>
                    <th className="px-3 py-2 text-start font-medium">التاريخ</th>
                    <th className="px-3 py-2 text-start font-medium">الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {recent.map((d) => (
                    <tr key={d.id} className="border-b last:border-0">
                      <td className="px-3 py-3 font-semibold">{d.user.name}</td>
                      <td className="px-3 py-3">{d.service.nameAr}</td>
                      <td className="px-3 py-3 text-muted-foreground">{formatDate(d.createdAt, params.locale)}</td>
                      <td className="px-3 py-3">
                        <Badge tone={d.status === "COMPLETED" ? "success" : d.status === "FAILED" ? "danger" : "warning"}>
                          {d.status === "COMPLETED" ? "مكتمل" : d.status === "FAILED" ? "فشل" : "قيد المعالجة"}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
