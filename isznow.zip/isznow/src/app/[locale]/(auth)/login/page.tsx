import type { Metadata } from "next";
import { FileText } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { LoginForm } from "@/components/auth/login-form";

export const metadata: Metadata = { title: "تسجيل الدخول" };

export default function LoginPage({ params }: { params: { locale: string } }) {
  return (
    <main className="flex min-h-screen items-center justify-center bg-gradient-to-br from-indigo-50 via-background to-violet-100 p-4">
      <div className="w-full max-w-md">
        <div className="mb-6 flex flex-col items-center gap-3 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg">
            <FileText className="h-7 w-7" />
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight">
            ISZ <span className="text-primary">Now</span>
          </h1>
          <p className="text-sm text-muted-foreground">منصة توليد الوثائق الاحترافية بالذكاء الاصطناعي</p>
        </div>

        <Card>
          <CardContent className="p-6">
            <h2 className="mb-1 text-lg font-bold">مرحباً بعودتك</h2>
            <p className="mb-5 text-sm text-muted-foreground">سجّل دخولك للوصول إلى لوحة التحكم</p>
            <LoginForm locale={params.locale} />
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
