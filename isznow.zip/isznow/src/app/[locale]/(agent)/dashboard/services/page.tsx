import Link from "next/link";
import { BookOpen, FileSignature, Receipt, UserSquare2 } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { Card, CardContent } from "@/components/ui/card";

export const metadata = { title: "الخدمات" };

const ICONS = { CV: UserSquare2, RESEARCH: BookOpen, INVOICE: Receipt, LETTER: FileSignature };

export default async function ServicesPage({ params }: { params: { locale: string } }) {
  const services = await prisma.service.findMany({ where: { isActive: true }, orderBy: { pointsCost: "desc" } });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">الخدمات</h1>
        <p className="text-sm text-muted-foreground">اختر الخدمة التي يحتاجها زبونك</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        {services.map((s) => {
          const Icon = ICONS[s.templateType];
          return (
            <Link key={s.id} href={`/${params.locale}/dashboard/services/${s.slug}`}>
              <Card className="h-full transition-all hover:-translate-y-0.5 hover:shadow-md">
                <CardContent className="flex gap-4 p-6">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-accent text-primary">
                    <Icon className="h-7 w-7" />
                  </div>
                  <div>
                    <p className="text-lg font-bold">{s.nameAr}</p>
                    <p className="mt-1 text-sm text-muted-foreground">{s.descriptionAr}</p>
                    <p className="mt-3 text-sm font-extrabold text-primary">{s.pointsCost} نقطة</p>
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
