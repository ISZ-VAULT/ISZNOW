import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import { ServiceWizard } from "@/components/wizards/service-wizard";

export default async function ServicePage({ params }: { params: { locale: string; slug: string } }) {
  const user = await requireUser(params.locale);
  const service = await prisma.service.findUnique({ where: { slug: params.slug } });
  if (!service || !service.isActive) notFound();

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">{service.nameAr}</h1>
        <p className="text-sm text-muted-foreground">{service.descriptionAr}</p>
      </div>
      <ServiceWizard
        locale={params.locale}
        balance={user.pointsBalance}
        service={{
          id: service.id,
          templateType: service.templateType,
          pointsCost: service.pointsCost,
          nameAr: service.nameAr,
        }}
      />
    </div>
  );
}
