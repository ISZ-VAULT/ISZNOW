import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import { formatDate } from "@/lib/utils";
import { Badge, Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { RechargeForm } from "@/components/agent/recharge-form";

export const metadata = { title: "شحن الرصيد" };

const TYPE_LABEL = {
  RECHARGE: "شحن",
  DEDUCTION: "خصم",
  REFUND: "استرجاع",
  ADJUSTMENT: "تعديل إداري",
} as const;

export default async function RechargePage({ params }: { params: { locale: string } }) {
  const user = await requireUser(params.locale);
  const history = await prisma.transaction.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 10,
  });

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">شحن الرصيد</h1>
        <p className="text-sm text-muted-foreground">أدخل كود البطاقة التي اشتريتها لإضافة النقاط إلى حسابك</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>بطاقة الشحن</CardTitle>
          <CardDescription>جرّب الكود: 234567890123 (4000 نقطة)</CardDescription>
        </CardHeader>
        <CardContent>
          <RechargeForm />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>آخر العمليات</CardTitle>
        </CardHeader>
        <CardContent>
          {history.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">لا توجد عمليات بعد</p>
          ) : (
            <ul className="divide-y">
              {history.map((t) => (
                <li key={t.id} className="flex items-center justify-between py-3 text-sm">
                  <div>
                    <p className="font-semibold">{TYPE_LABEL[t.type]}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(t.createdAt, params.locale)}</p>
                  </div>
                  <Badge tone={t.points >= 0 ? "success" : "danger"}>
                    {t.points >= 0 ? "+" : ""}
                    {t.points}
                  </Badge>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
