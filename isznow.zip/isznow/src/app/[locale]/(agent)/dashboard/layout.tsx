import { requireUser } from "@/lib/session";
import { AppShell, type NavItem } from "@/components/layout/app-shell";

export const dynamic = "force-dynamic";

export default async function AgentLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  const user = await requireUser(params.locale);
  const base = `/${params.locale}/dashboard`;

  const nav: NavItem[] = [
    { href: base, label: "لوحة التحكم", icon: "dashboard" },
    { href: `${base}/services`, label: "الخدمات", icon: "services" },
    { href: `${base}/recharge`, label: "شحن الرصيد", icon: "recharge" },
    { href: `${base}/documents`, label: "وثائقي", icon: "documents" },
  ];

  return (
    <AppShell
      locale={params.locale}
      nav={nav}
      exactHref={base}
      userName={user.name}
      roleLabel={user.role === "ADMIN" ? "مدير" : "وكيل"}
      points={user.pointsBalance}
    >
      {children}
    </AppShell>
  );
}
