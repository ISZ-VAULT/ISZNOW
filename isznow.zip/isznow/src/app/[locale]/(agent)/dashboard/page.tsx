import Link from "next/link";
import { Coins, FileText, TrendingDown, ArrowLeft } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import { formatNumber } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DocumentList } from "@/components/agent/document-list";

export const metadata = { title: "لوحة التحكم" };

export default async function DashboardPage({ params }: { params: { locale: string } }) {
  const user = await requireUser(params.locale);

  const [totalDocs, spent, recent, services] = await Promise.all([
    prisma.document.count({ where: { userId: user.id, status: "COMPLETED" } }),
    prisma.document.aggregate({
      where: { userId: user.id, status: "COMPLETED" },
      _sum: { pointsCharged: true },
    }),
    prisma.document.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      take: 5,
      include: { service: { select: { nameAr: true } } },
    }),
    prisma.service.findMany({ where: { isActive: true }, orderBy: { pointsCost: "desc" } }),
  ]);

  const stats = [
    { label: "رصيد النقاط", value: formatNumber(user.pointsBalance), icon: Coins, color: "bg-indigo-100 text-indigo-600" },
    { label: "الوثائق المنجزة", value: formatNumber(totalDocs), icon: FileText, color: "bg-emerald-100 text-emerald-600" },
    { label: "النقاط المستهلكة", value: formatNumber(spent._sum.pointsCharged ?? 0), icon: TrendingDown, color: "bg-amber-100 text-amber-600" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">لوحة التحكم</h1>
        <p className="text-sm text-muted-foreground">نظرة عامة على حسابك في ISZ Now</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardContent className="flex items-center gap-4 p-5">
              <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${s.color}`}>
                <s.icon className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{s.label}</p>
                <p className="text-2xl font-extrabold">{s.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div>
        <h2 className="mb-3 text-lg font-bold">وصول سريع للخدمات</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((s) => (
            <Link key={s.id} href={`/${params.locale}/dashboard/services/${s.slug}`}>
              <Card className="h-full transition-shadow hover:shadow-md">
                <CardContent className="p-5">
                  <p className="font-bold">{s.nameAr}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{s.descriptionAr}</p>
                  <p className="mt-3 text-sm font-bold text-primary">{s.pointsCost} نقطة</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      <Card>
        <CardHeader className="flex-row items-center justify-between">
          <CardTitle>آخر الوثائق</CardTitle>
          <Link href={`/${params.locale}/dashboard/documents`} className="flex items-center gap-1 text-sm font-semibold text-primary">
            عرض الكل <ArrowLeft className="h-4 w-4 rtl:rotate-0 ltr:rotate-180" />
          </Link>
        </CardHeader>
        <CardContent>
          <DocumentList docs={recent} locale={params.locale} />
        </CardContent>
      </Card>
    </div>
  );
}
