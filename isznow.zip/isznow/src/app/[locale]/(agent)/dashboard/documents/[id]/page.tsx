import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import { DocumentView } from "@/components/agent/document-view";
import { PdfButton } from "@/components/agent/pdf-button";

export default async function DocumentPage({ params }: { params: { locale: string; id: string } }) {
  const user = await requireUser(params.locale);
  const doc = await prisma.document.findUnique({
    where: { id: params.id },
    include: { service: { select: { nameAr: true } } },
  });
  // Agents can only see their own documents
  if (!doc || (doc.userId !== user.id && user.role !== "ADMIN") || !doc.outputContent) notFound();

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <Link href={`/${params.locale}/dashboard/documents`} className="text-sm font-semibold text-primary">
            ← كل الوثائق
          </Link>
          <h1 className="text-2xl font-extrabold">{doc.service.nameAr}</h1>
        </div>
        <PdfButton />
      </div>
      <DocumentView content={doc.outputContent} rtl={doc.language === "ar"} />
    </div>
  );
}
