import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/session";
import { Card, CardContent } from "@/components/ui/card";
import { DocumentList } from "@/components/agent/document-list";

export const metadata = { title: "وثائقي" };

export default async function DocumentsPage({ params }: { params: { locale: string } }) {
  const user = await requireUser(params.locale);
  const docs = await prisma.document.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 100,
    include: { service: { select: { nameAr: true } } },
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">وثائقي</h1>
        <p className="text-sm text-muted-foreground">جميع الوثائق التي أنشأتها</p>
      </div>
      <Card>
        <CardContent className="p-5">
          <DocumentList docs={docs} locale={params.locale} />
        </CardContent>
      </Card>
    </div>
  );
}
