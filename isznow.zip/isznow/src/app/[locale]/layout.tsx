import type { Metadata } from "next";
import { Cairo } from "next/font/google";
import "../globals.css";
import { Providers } from "@/components/providers";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  variable: "--font-cairo",
  display: "swap",
});

export const metadata: Metadata = {
  title: { default: "ISZ Now", template: "%s | ISZ Now" },
  description: "ISZ Now — منصة توليد الوثائق بالذكاء الاصطناعي",
};

export default function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  const dir = params.locale === "ar" ? "rtl" : "ltr";
  return (
    <html lang={params.locale} dir={dir}>
      <body className={`${cairo.variable} font-sans`}>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
