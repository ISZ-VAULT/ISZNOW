"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import {
  CreditCard,
  FileText,
  LayoutDashboard,
  LogOut,
  Sparkles,
  Users,
  Wallet,
  Layers,
  Coins,
} from "lucide-react";
import { cn, formatNumber } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const ICONS = {
  dashboard: LayoutDashboard,
  services: Sparkles,
  recharge: Wallet,
  documents: FileText,
  users: Users,
  cards: CreditCard,
  layers: Layers,
} as const;

export type NavItem = { href: string; label: string; icon: keyof typeof ICONS };

export function AppShell({
  locale,
  nav,
  userName,
  roleLabel,
  points,
  exactHref,
  children,
}: {
  locale: string;
  nav: NavItem[];
  userName: string;
  roleLabel: string;
  points?: number;
  /** href of the "home" item, matched exactly so it isn't always highlighted */
  exactHref: string;
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const isActive = (href: string) =>
    href === exactHref ? pathname === href : pathname === href || pathname.startsWith(href + "/");

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-e bg-card md:flex">
        <div className="flex h-16 items-center gap-2 border-b px-5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <FileText className="h-5 w-5" />
          </div>
          <span className="text-xl font-extrabold">
            ISZ <span className="text-primary">Now</span>
          </span>
        </div>
        <nav className="flex-1 space-y-1 p-3">
          {nav.map((item) => {
            const Icon = ICONS[item.icon];
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-semibold transition-colors",
                  isActive(item.href)
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                )}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t p-3">
          <Button
            variant="ghost"
            className="w-full justify-start text-muted-foreground"
            onClick={() => signOut({ callbackUrl: `/${locale}/login` })}
          >
            <LogOut className="h-4 w-4" />
            تسجيل الخروج
          </Button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Topbar */}
        <header className="sticky top-0 z-10 flex h-16 items-center justify-between border-b bg-card/90 px-4 backdrop-blur md:px-8">
          <div className="flex items-center gap-2 md:hidden">
            <FileText className="h-5 w-5 text-primary" />
            <span className="font-extrabold">
              ISZ <span className="text-primary">Now</span>
            </span>
          </div>
          <div className="hidden text-sm text-muted-foreground md:block">
            مرحباً، <span className="font-bold text-foreground">{userName}</span>
          </div>

          <div className="flex items-center gap-3">
            {points !== undefined && (
              <div className="flex items-center gap-2 rounded-full bg-accent px-4 py-1.5 text-sm font-bold text-accent-foreground">
                <Coins className="h-4 w-4" />
                <span>{formatNumber(points)}</span>
                <span className="text-xs font-medium">نقطة</span>
              </div>
            )}
            <span className="hidden rounded-md bg-secondary px-2 py-1 text-xs font-semibold sm:inline">{roleLabel}</span>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => signOut({ callbackUrl: `/${locale}/login` })}
              aria-label="تسجيل الخروج"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </header>

        {/* Mobile nav */}
        <nav className="flex gap-1 overflow-x-auto border-b bg-card px-3 py-2 md:hidden">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold",
                isActive(item.href) ? "bg-primary text-primary-foreground" : "bg-secondary"
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <main className="flex-1 p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}
