"use client";

import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";

/** Placeholder: real Puppeteer PDF generation comes in the next phase. */
export function PdfButton() {
  return (
    <Button
      variant="outline"
      onClick={() => alert("تحميل PDF سيتم تفعيله في المرحلة القادمة (Puppeteer).")}
    >
      <Download className="h-4 w-4" />
      تحميل PDF
    </Button>
  );
}
