"use client";

import { useState } from "react";
import { Input, Select, Textarea } from "@/components/ui/input";
import { Field, RepeatableRows } from "./fields";

/**
 * Each form exposes a `build()` result through onChange: the parsed input object
 * the API expects. The parent wizard calls it on submit.
 */
export type FormHandle = { build: () => unknown };
type Props = { register: (h: FormHandle) => void };

/* ───────────── CV ───────────── */
export function CvForm({ register }: Props) {
  const [fullName, setFullName] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [skills, setSkills] = useState("");
  const [experience, setExperience] = useState([{ company: "", role: "", period: "", details: "" }]);
  const [education, setEducation] = useState([{ school: "", degree: "", period: "" }]);

  register({
    build: () => ({
      fullName,
      jobTitle,
      experience: experience.filter((e) => e.company || e.role),
      education: education.filter((e) => e.school || e.degree),
      skills: skills.split(/[,،\n]/).map((s) => s.trim()).filter(Boolean),
    }),
  });

  return (
    <div className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="الاسم الكامل">
          <Input required value={fullName} onChange={(e) => setFullName(e.target.value)} />
        </Field>
        <Field label="المسمى الوظيفي / الوظيفة المطلوبة">
          <Input required value={jobTitle} onChange={(e) => setJobTitle(e.target.value)} />
        </Field>
      </div>
      <RepeatableRows
        title="الخبرات المهنية"
        rows={experience}
        setRows={setExperience}
        empty={{ company: "", role: "", period: "", details: "" }}
        columns={[
          { key: "company", label: "المؤسسة" },
          { key: "role", label: "المنصب" },
          { key: "period", label: "الفترة" },
          { key: "details", label: "تفاصيل" },
        ]}
      />
      <RepeatableRows
        title="التكوين والشهادات"
        rows={education}
        setRows={setEducation}
        empty={{ school: "", degree: "", period: "" }}
        columns={[
          { key: "school", label: "المؤسسة" },
          { key: "degree", label: "الشهادة" },
          { key: "period", label: "الفترة" },
        ]}
      />
      <Field label="المهارات (افصل بينها بفاصلة)">
        <Input value={skills} onChange={(e) => setSkills(e.target.value)} placeholder="Word, Excel, Anglais..." />
      </Field>
    </div>
  );
}

/* ───────────── Research ───────────── */
export function ResearchForm({ register }: Props) {
  const [subject, setSubject] = useState("");
  const [level, setLevel] = useState("المتوسط");
  const [pages, setPages] = useState("5");
  const [includeImages, setIncludeImages] = useState(false);

  register({ build: () => ({ subject, level, pages: Number(pages), includeImages }) });

  return (
    <div className="space-y-4">
      <Field label="موضوع البحث">
        <Input required value={subject} onChange={(e) => setSubject(e.target.value)} />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="المستوى الدراسي">
          <Select value={level} onChange={(e) => setLevel(e.target.value)}>
            {["الابتدائي", "المتوسط", "الثانوي", "الجامعي"].map((l) => (
              <option key={l}>{l}</option>
            ))}
          </Select>
        </Field>
        <Field label="عدد الصفحات (1 - 30)">
          <Input type="number" min={1} max={30} required value={pages} onChange={(e) => setPages(e.target.value)} />
        </Field>
      </div>
      <label className="flex cursor-pointer items-center gap-2 text-sm font-medium">
        <input type="checkbox" checked={includeImages} onChange={(e) => setIncludeImages(e.target.checked)} className="h-4 w-4" />
        إضافة أماكن مخصصة للصور
      </label>
    </div>
  );
}

/* ───────────── Invoice ───────────── */
export function InvoiceForm({ register }: Props) {
  const [seller, setSeller] = useState({ name: "", address: "", nif: "" });
  const [buyer, setBuyer] = useState({ name: "", address: "" });
  const [tvaRate, setTvaRate] = useState("19");
  const [items, setItems] = useState([{ description: "", quantity: "1", unitPrice: "" }]);

  register({
    build: () => ({
      seller,
      buyer,
      tvaRate: Number(tvaRate),
      items: items
        .filter((i) => i.description)
        .map((i) => ({ description: i.description, quantity: Number(i.quantity), unitPrice: Number(i.unitPrice) })),
    }),
  });

  const ht = items.reduce((s, i) => s + (Number(i.quantity) || 0) * (Number(i.unitPrice) || 0), 0);
  const tva = (ht * (Number(tvaRate) || 0)) / 100;

  return (
    <div className="space-y-5">
      <div className="grid gap-6 sm:grid-cols-2">
        <div className="space-y-3">
          <h3 className="font-bold">البائع</h3>
          <Input required placeholder="الاسم / الشركة" value={seller.name} onChange={(e) => setSeller({ ...seller, name: e.target.value })} />
          <Input placeholder="العنوان" value={seller.address} onChange={(e) => setSeller({ ...seller, address: e.target.value })} />
          <Input placeholder="NIF" dir="ltr" value={seller.nif} onChange={(e) => setSeller({ ...seller, nif: e.target.value })} />
        </div>
        <div className="space-y-3">
          <h3 className="font-bold">الزبون</h3>
          <Input required placeholder="الاسم / الشركة" value={buyer.name} onChange={(e) => setBuyer({ ...buyer, name: e.target.value })} />
          <Input placeholder="العنوان" value={buyer.address} onChange={(e) => setBuyer({ ...buyer, address: e.target.value })} />
        </div>
      </div>
      <RepeatableRows
        title="المنتجات / الخدمات"
        rows={items}
        setRows={setItems}
        empty={{ description: "", quantity: "1", unitPrice: "" }}
        columns={[
          { key: "description", label: "الوصف" },
          { key: "quantity", label: "الكمية", type: "number" },
          { key: "unitPrice", label: "سعر الوحدة (دج)", type: "number" },
        ]}
      />
      <div className="grid items-end gap-4 rounded-md bg-muted/50 p-4 sm:grid-cols-4">
        <Field label="TVA %">
          <Input type="number" min={0} max={100} value={tvaRate} onChange={(e) => setTvaRate(e.target.value)} />
        </Field>
        <div className="text-sm"><p className="text-muted-foreground">المجموع HT</p><p className="font-bold">{ht.toLocaleString("fr-DZ")} دج</p></div>
        <div className="text-sm"><p className="text-muted-foreground">TVA</p><p className="font-bold">{tva.toLocaleString("fr-DZ")} دج</p></div>
        <div className="text-sm"><p className="text-muted-foreground">المجموع TTC</p><p className="text-lg font-extrabold text-primary">{(ht + tva).toLocaleString("fr-DZ")} دج</p></div>
      </div>
    </div>
  );
}

/* ───────────── Letter ───────────── */
const LETTER_TYPES = ["طلب عمل", "طلب إجازة", "شكوى", "طلب استقالة", "طلب شهادة", "رسالة رسمية أخرى"];

export function LetterForm({ register }: Props) {
  const [letterType, setLetterType] = useState(LETTER_TYPES[0]);
  const [subject, setSubject] = useState("");
  const [sender, setSender] = useState("");
  const [recipient, setRecipient] = useState("");
  const [details, setDetails] = useState("");

  register({ build: () => ({ letterType, subject, sender, recipient, details: details || undefined }) });

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="نوع الرسالة">
          <Select value={letterType} onChange={(e) => setLetterType(e.target.value)}>
            {LETTER_TYPES.map((t) => <option key={t}>{t}</option>)}
          </Select>
        </Field>
        <Field label="الموضوع">
          <Input required value={subject} onChange={(e) => setSubject(e.target.value)} />
        </Field>
        <Field label="المرسل (الاسم والعنوان)">
          <Input required value={sender} onChange={(e) => setSender(e.target.value)} />
        </Field>
        <Field label="المرسل إليه (الجهة)">
          <Input required value={recipient} onChange={(e) => setRecipient(e.target.value)} />
        </Field>
      </div>
      <Field label="تفاصيل إضافية (اختياري)">
        <Textarea value={details} onChange={(e) => setDetails(e.target.value)} maxLength={2000} />
      </Field>
    </div>
  );
}
