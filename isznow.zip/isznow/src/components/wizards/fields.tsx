"use client";

import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";

export function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <Label>{label}</Label>
      {children}
    </div>
  );
}

export function RepeatableRows<T extends Record<string, any>>({
  title,
  rows,
  setRows,
  empty,
  columns,
}: {
  title: string;
  rows: T[];
  setRows: (r: T[]) => void;
  empty: T;
  columns: { key: keyof T & string; label: string; type?: string }[];
}) {
  const update = (i: number, key: string, value: string) =>
    setRows(rows.map((r, idx) => (idx === i ? { ...r, [key]: value } : r)));

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="font-bold">{title}</h3>
        <Button type="button" variant="outline" size="sm" onClick={() => setRows([...rows, { ...empty }])}>
          <Plus className="h-3.5 w-3.5" /> إضافة
        </Button>
      </div>
      {rows.map((row, i) => (
        <div key={i} className="grid gap-3 rounded-md border bg-muted/30 p-3 sm:grid-cols-[repeat(auto-fit,minmax(130px,1fr))_auto]">
          {columns.map((c) => (
            <div key={c.key}>
              <Label className="text-xs text-muted-foreground">{c.label}</Label>
              <Input
                type={c.type ?? "text"}
                value={row[c.key] as string}
                onChange={(e) => update(i, c.key, e.target.value)}
              />
            </div>
          ))}
          <div className="flex items-end">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="text-destructive"
              onClick={() => setRows(rows.filter((_, idx) => idx !== i))}
              aria-label="حذف"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}
