"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, RotateCcw, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Field } from "./fields";
import { Select } from "@/components/ui/input";
import { CvForm, InvoiceForm, LetterForm, ResearchForm, type FormHandle } from "./forms";
import { DocumentView } from "@/components/agent/document-view";
import { PdfButton } from "@/components/agent/pdf-button";

type TemplateType = "CV" | "RESEARCH" | "INVOICE" | "LETTER";

const ERRORS: Record<string, string> = {
  INSUFFICIENT_POINTS_OR_BANNED: "رصيدك غير كافٍ. اشحن رصيدك ثم أعد المحاولة.",
  AI_FAILED_REFUNDED: "فشل التوليد. تمت إعادة النقاط إلى رصيدك تلقائياً.",
  INVALID_INPUT: "بعض الحقول غير صالحة، راجع البيانات المدخلة.",
  SERVICE_UNAVAILABLE: "هذه الخدمة غير متاحة حالياً.",
};

export function ServiceWizard({
  service,
  balance,
  locale,
}: {
  service: { id: string; templateType: TemplateType; pointsCost: number; nameAr: string };
  balance: number;
  locale: string;
}) {
  const router = useRouter();
  const handle = useRef<FormHandle | null>(null);
  const register = (h: FormHandle) => {
    handle.current = h;
  };

  const [language, setLanguage] = useState<"ar" | "fr" | "en">("fr");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<{ content: string; documentId: string } | null>(null);

  const insufficient = balance < service.pointsCost;

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!handle.current) return;
    setLoading(true);
    setError("");

    const res = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ serviceId: service.id, language, inputData: handle.current.build() }),
    });
    const data = await res.json().catch(() => ({}));
    setLoading(false);

    if (!res.ok) {
      setError(ERRORS[data.error] ?? "حدث خطأ غير متوقع");
      router.refresh(); // balance may have been refunded
      return;
    }
    setResult({ content: data.content, documentId: data.documentId });
    router.refresh(); // update topbar balance
  }

  /* ── Result screen ── */
  if (result) {
    return (
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg bg-emerald-50 p-4 text-emerald-800">
          <p className="font-bold">تم إنشاء الوثيقة بنجاح ✓</p>
          <div className="flex gap-2">
            <PdfButton />
            <Button variant="secondary" onClick={() => setResult(null)}>
              <RotateCcw className="h-4 w-4" /> وثيقة جديدة
            </Button>
          </div>
        </div>
        <DocumentView content={result.content} rtl={language === "ar"} />
      </div>
    );
  }

  /* ── Form screen ── */
  return (
    <form onSubmit={onSubmit}>
      <Card>
        <CardContent className="space-y-6 p-6">
          {service.templateType === "CV" && <CvForm register={register} />}
          {service.templateType === "RESEARCH" && <ResearchForm register={register} />}
          {service.templateType === "INVOICE" && <InvoiceForm register={register} />}
          {service.templateType === "LETTER" && <LetterForm register={register} />}

          <div className="max-w-xs">
            <Field label="لغة الوثيقة">
              <Select value={language} onChange={(e) => setLanguage(e.target.value as "ar" | "fr" | "en")}>
                <option value="fr">Français</option>
                <option value="ar">العربية</option>
                <option value="en">English</option>
              </Select>
            </Field>
          </div>

          {error && <p className="rounded-md bg-red-50 p-3 text-sm text-destructive">{error}</p>}
          {insufficient && (
            <p className="rounded-md bg-amber-50 p-3 text-sm text-amber-800">
              رصيدك ({balance}) أقل من تكلفة الخدمة ({service.pointsCost}).
            </p>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3 border-t pt-4">
            <p className="text-sm text-muted-foreground">
              التكلفة: <span className="font-extrabold text-foreground">{service.pointsCost} نقطة</span>
            </p>
            <Button type="submit" size="lg" disabled={loading || insufficient}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              {loading ? "جارٍ التوليد..." : "توليد الوثيقة"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </form>
  );
}
