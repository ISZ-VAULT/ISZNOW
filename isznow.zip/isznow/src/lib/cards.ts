import { randomInt } from "crypto";

/** Cryptographically random 12-digit code (never starts with 0). */
export function generateCardCode(): string {
  let code = String(randomInt(1, 10));
  for (let i = 0; i < 11; i++) code += String(randomInt(0, 10));
  return code;
}
