import OpenAI from "openai";
import { GoogleGenerativeAI } from "@google/generative-ai";
import { TemplateType } from "@prisma/client";
import { buildPrompt } from "./prompts";

/** Fake content so you can click through the app without API keys. */
function mockContent(type: TemplateType, input: any): string {
  const note = "\n\n---\n*(Mock content: set OPENAI_API_KEY in .env for real AI output.)*";
  switch (type) {
    case "CV":
      return (
        `# ${input.fullName}\n**${input.jobTitle}**\n\n## Profil\nProfessionnel motivé et rigoureux.\n\n` +
        `## Expérience\n${(input.experience ?? [])
          .map((e: any) => `- **${e.role}**, ${e.company} (${e.period})${e.details ? `: ${e.details}` : ""}`)
          .join("\n") || "- Aucune"}\n\n` +
        `## Formation\n${(input.education ?? [])
          .map((e: any) => `- **${e.degree}**, ${e.school} (${e.period})`)
          .join("\n") || "- Aucune"}\n\n` +
        `## Compétences\n${(input.skills ?? []).map((s: string) => `- ${s}`).join("\n") || "- -"}` +
        note
      );
    case "RESEARCH":
      return (
        `# ${input.subject}\n*Niveau : ${input.level} — ${input.pages} page(s)*\n\n## Introduction\nCe travail présente le sujet « ${input.subject} ».\n\n` +
        `## Chapitre 1\nContenu du premier chapitre.\n\n## Chapitre 2\nContenu du deuxième chapitre.\n\n## Conclusion\nSynthèse du travail.\n\n## Références\n- Référence 1\n- Référence 2` +
        note
      );
    case "INVOICE": {
      const items: any[] = input.items ?? [];
      const ht = items.reduce((s, i) => s + i.quantity * i.unitPrice, 0);
      const tva = (ht * (input.tvaRate ?? 19)) / 100;
      return (
        `# FACTURE\n\n**Vendeur :** ${input.seller?.name}\n\n**Client :** ${input.buyer?.name}\n\n` +
        `| Description | Qté | PU | Total |\n|---|---|---|---|\n` +
        items.map((i) => `| ${i.description} | ${i.quantity} | ${i.unitPrice} | ${i.quantity * i.unitPrice} |`).join("\n") +
        `\n\n**Total HT :** ${ht} DZD\n\n**TVA (${input.tvaRate}%) :** ${tva.toFixed(2)} DZD\n\n**Total TTC :** ${(ht + tva).toFixed(2)} DZD` +
        note
      );
    }
    case "LETTER":
      return (
        `**De :** ${input.sender}\n\n**À :** ${input.recipient}\n\n**Objet :** ${input.subject}\n\n` +
        `Madame, Monsieur,\n\nJe vous écris au sujet de : ${input.subject}. ${input.details ?? ""}\n\n` +
        `Veuillez agréer, Madame, Monsieur, l'expression de mes salutations distinguées.` +
        note
      );
  }
}

export async function generateContent(
  type: TemplateType,
  language: string,
  input: unknown
): Promise<string> {
  const hasOpenAI = !!process.env.OPENAI_API_KEY;
  const hasGemini = !!process.env.GEMINI_API_KEY;

  if (!hasOpenAI && !hasGemini) {
    await new Promise((r) => setTimeout(r, 1200)); // feel like a real call
    return mockContent(type, input);
  }

  const { system, user } = buildPrompt(type, language, input);
  let firstError: unknown;

  if (hasOpenAI) {
    try {
      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
      const res = await openai.chat.completions.create(
        {
          model: "gpt-4o",
          temperature: 0.6,
          messages: [
            { role: "system", content: system },
            { role: "user", content: user },
          ],
        },
        { timeout: 60_000 }
      );
      const text = res.choices[0]?.message?.content?.trim();
      if (text) return text;
      firstError = new Error("Empty OpenAI response");
    } catch (err) {
      firstError = err;
    }
  }

  if (hasGemini) {
    const gemini = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);
    const model = gemini.getGenerativeModel({ model: "gemini-1.5-pro" });
    const res = await model.generateContent(`${system}\n\n${user}`);
    const text = res.response.text().trim();
    if (text) return text;
  }

  throw firstError ?? new Error("AI generation failed");
}
