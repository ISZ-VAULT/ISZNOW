import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(d: Date | string, locale = "ar") {
  return new Date(d).toLocaleDateString(locale === "ar" ? "ar-DZ" : "fr-DZ", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

/** "123456789012" -> "1234 5678 9012" */
export function formatCode(code: string) {
  return code.replace(/(\d{4})(?=\d)/g, "$1 ");
}

export function formatNumber(n: number) {
  return new Intl.NumberFormat("fr-DZ").format(n);
}
