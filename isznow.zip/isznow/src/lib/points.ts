import { prisma } from "@/lib/prisma";
import { Prisma } from "@prisma/client";

export class InsufficientPointsError extends Error {}

/** Atomically charge points and create a PENDING document. */
export async function chargeAndCreateDocument(params: {
  userId: string;
  serviceId: string;
  cost: number;
  inputData: Prisma.InputJsonValue;
  language: string;
}) {
  const { userId, serviceId, cost, inputData, language } = params;

  return prisma.$transaction(async (tx) => {
    // Single conditional UPDATE: no double-spend, banned users rejected.
    const updated = await tx.user.updateMany({
      where: { id: userId, isBanned: false, pointsBalance: { gte: cost } },
      data: { pointsBalance: { decrement: cost } },
    });
    if (updated.count === 0) throw new InsufficientPointsError();

    const user = await tx.user.findUniqueOrThrow({
      where: { id: userId },
      select: { pointsBalance: true },
    });

    const document = await tx.document.create({
      data: { userId, serviceId, inputData, language, pointsCharged: cost },
    });

    await tx.transaction.create({
      data: {
        userId,
        type: "DEDUCTION",
        method: "SYSTEM",
        points: -cost,
        balanceAfter: user.pointsBalance,
        documentId: document.id,
      },
    });

    return document;
  });
}

export async function refundDocument(documentId: string, errorMessage: string) {
  return prisma.$transaction(async (tx) => {
    const doc = await tx.document.update({
      where: { id: documentId },
      data: { status: "FAILED", errorMessage },
    });
    const user = await tx.user.update({
      where: { id: doc.userId },
      data: { pointsBalance: { increment: doc.pointsCharged } },
      select: { pointsBalance: true },
    });
    await tx.transaction.create({
      data: {
        userId: doc.userId,
        type: "REFUND",
        method: "SYSTEM",
        points: doc.pointsCharged,
        balanceAfter: user.pointsBalance,
        documentId: doc.id,
      },
    });
  });
}
