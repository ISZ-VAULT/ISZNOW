import { z } from "zod";
import { TemplateType } from "@prisma/client";

export const generateRequestSchema = z.object({
  serviceId: z.string().min(1),
  language: z.enum(["ar", "fr", "en"]).default("fr"),
  inputData: z.record(z.any()),
});

export const inputSchemas: Record<TemplateType, z.ZodTypeAny> = {
  RESEARCH: z.object({
    subject: z.string().min(2).max(200),
    level: z.string().max(50),
    pages: z.number().int().min(1).max(30),
    includeImages: z.boolean().default(false),
  }),
  CV: z.object({
    fullName: z.string().min(2).max(100),
    jobTitle: z.string().min(2).max(100),
    experience: z
      .array(z.object({ company: z.string(), role: z.string(), period: z.string(), details: z.string().optional() }))
      .max(15),
    education: z.array(z.object({ school: z.string(), degree: z.string(), period: z.string() })).max(10),
    skills: z.array(z.string()).max(30).optional(),
  }),
  INVOICE: z.object({
    seller: z.object({ name: z.string().min(1), address: z.string().optional(), nif: z.string().optional() }),
    buyer: z.object({ name: z.string().min(1), address: z.string().optional() }),
    items: z
      .array(z.object({ description: z.string().min(1), quantity: z.number().positive(), unitPrice: z.number().nonnegative() }))
      .min(1)
      .max(50),
    tvaRate: z.number().min(0).max(100).default(19),
  }),
  LETTER: z.object({
    letterType: z.string().min(1).max(100),
    subject: z.string().min(1).max(200),
    sender: z.string().min(1).max(200),
    recipient: z.string().min(1).max(200),
    details: z.string().max(2000).optional(),
  }),
};
