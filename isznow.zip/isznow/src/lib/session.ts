import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

/** For server components / layouts. Redirects to login when not signed in. */
export async function requireUser(locale: string) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) redirect(`/${locale}/login`);

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    select: { id: true, name: true, email: true, role: true, pointsBalance: true, isBanned: true },
  });
  if (!user || user.isBanned) redirect(`/${locale}/login`);
  return user;
}

export async function requireAdminPage(locale: string) {
  const user = await requireUser(locale);
  if (user.role !== "ADMIN") redirect(`/${locale}/dashboard`);
  return user;
}

/** For API routes. Returns null when not an admin. */
export async function getAdminSession() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id || session.user.role !== "ADMIN") return null;
  return session.user;
}
